In Visual studio code with the help of an extension called code runner you press ctrl+shift/option+N to run the code. 
